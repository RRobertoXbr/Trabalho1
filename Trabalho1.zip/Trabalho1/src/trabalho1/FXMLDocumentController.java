/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;

import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

/**
 *
 * @author roberto
 */
public class FXMLDocumentController implements Initializable {
    
    @FXML // fx:id="saque"
    private Button saque; // Value injected by FXMLLoader

    @FXML // fx:id="deposito"
    private Button deposito; // Value injected by FXMLLoader

    @FXML // fx:id="transfer"
    private Button transfer; // Value injected by FXMLLoader

    @FXML // fx:id="reajustar"
    private Button reajustar; // Value injected by FXMLLoader

    @FXML // fx:id="sair"
    private Button sair; // Value injected by FXMLLoader
    
    @FXML
    private Button cadastro; //conta normal
    
    @FXML // fx:id="cadastro1" 
    private Button cadastro1; //conta poupanca
    
    @FXML // fx:id="saldos" 
    private Button saldos; //Ver Saldos

    @FXML // fx:id="cadastro11"
    private Button cadastro11;
    // vai armazenar as diversas contas.
    //conta especial
    
    Map<Integer, Contas> contas = new HashMap<>();
    
    public FXMLDocumentController() {
    }
    
    @FXML
    private void cadastro(){
        TextInputDialog dialog  =  new TextInputDialog("nome da conta");
        dialog.setTitle("Cadastro de Conta");
        dialog.setHeaderText("Cadastro de Conta");
        dialog.setContentText("Insira seu nome: ");
        
        TextInputDialog dialog2 =  new TextInputDialog("numero da conta");
        dialog2.setTitle("Cadastro de Conta");
        dialog2.setHeaderText("Cadastro de numero");
        dialog2.setContentText("Insira seu numero de conta: ");
        
        TextInputDialog dialog3 =  new TextInputDialog("saldo da conta");
        dialog3.setTitle("Cadastro de Conta");
        dialog3.setHeaderText("Digite seu saldo");
        dialog3.setContentText("Insira seu saldo de conta: ");
        
        String nome = null;
        int numero = 0;
        double saldo = 0;
        
        // Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();
        Optional<String> result2 = dialog2.showAndWait();
        Optional<String> result3 = dialog3.showAndWait();
        if (result.isPresent()){
            nome = result.get();
        }
        if (result2.isPresent()){
            numero = Integer.parseInt(result2.get());
        }
        if (result3.isPresent()){
            saldo = Double.parseDouble(result3.get());
        }
        contas.put(numero, new Contas(nome, numero, saldo));
    }
    
    @FXML
    private void cadastro1(){
        TextInputDialog dialog  =  new TextInputDialog("nome da conta");
        dialog.setTitle("Cadastro de Conta");
        dialog.setHeaderText("Cadastro de Conta");
        dialog.setContentText("Insira seu nome: ");
        
        TextInputDialog dialog2 =  new TextInputDialog("numero da conta");
        dialog2.setTitle("Cadastro de Conta");
        dialog2.setHeaderText("Cadastro de numero");
        dialog2.setContentText("Insira seu numero de conta: ");
        
        TextInputDialog dialog3 =  new TextInputDialog("saldo da conta");
        dialog3.setTitle("Cadastro de Conta");
        dialog3.setHeaderText("Digite seu saldo");
        dialog3.setContentText("Insira seu saldo de conta: ");
        
        TextInputDialog dialog4 =  new TextInputDialog(null);
        dialog4.setTitle("Cadastro de Conta");
        dialog4.setHeaderText("Digite o reajuste");
        dialog4.setContentText("Insira seu reajuste: ");
        
        String nome = null;
        int numero = 0;
        double saldo = 0;
        
        // Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();
        Optional<String> result2 = dialog2.showAndWait();
        Optional<String> result3 = dialog3.showAndWait();
        Optional<String> result4 = dialog4.showAndWait();
        if (result.isPresent()){
            nome = result.get();
        }
        if (result2.isPresent()){
            numero = Integer.parseInt(result2.get());
        }
        if (result3.isPresent()){
            saldo = Double.parseDouble(result3.get());
        }
        
        ContaPoupanca c1 = new ContaPoupanca(nome, numero, saldo); 
        contas.put(numero, c1);
        
        if (result4.isPresent()){
            c1.reajustar(Double.parseDouble(result4.get()));
        }else{
            c1.reajustar();
        }
    }
    
    @FXML
    private void cadastro11(){
        TextInputDialog dialog  =  new TextInputDialog("nome da conta");
        dialog.setTitle("Cadastro de Conta");
        dialog.setHeaderText("Cadastro de Conta");
        dialog.setContentText("Insira seu nome: ");
        
        TextInputDialog dialog2 =  new TextInputDialog("numero da conta");
        dialog2.setTitle("Cadastro de Conta");
        dialog2.setHeaderText("Cadastro de numero");
        dialog2.setContentText("Insira seu numero de conta: ");
        
        TextInputDialog dialog3 =  new TextInputDialog("saldo da conta");
        dialog3.setTitle("Cadastro de Conta");
        dialog3.setHeaderText("Digite seu saldo");
        dialog3.setContentText("Insira seu saldo de conta: ");
        
        TextInputDialog dialog4 =  new TextInputDialog(null);
        dialog4.setTitle("Cadastro de Conta");
        dialog4.setHeaderText("Digite o limite");
        dialog4.setContentText("Insira o limite da conta: ");
        
        TextInputDialog dialog5 =  new TextInputDialog(null);
        dialog5.setTitle("Cadastro de Conta");
        dialog5.setHeaderText("Digite a multa");
        dialog5.setContentText("Insira a multa da conta: ");
        
        String nome = null;
        int numero = 0;
        double saldo = 0;
        int limite = 0;
        double multa = 0;
        
        // Traditional way to get the response value.
        Optional<String> result = dialog.showAndWait();
        Optional<String> result2 = dialog2.showAndWait();
        Optional<String> result3 = dialog3.showAndWait();
        Optional<String> result4 = dialog4.showAndWait();
        Optional<String> result5 = dialog5.showAndWait();
        if (result.isPresent()){
            nome = result.get();
        }
        if (result2.isPresent()){
            numero = Integer.parseInt(result2.get());
        }
        if (result3.isPresent()){
            saldo = Double.parseDouble(result3.get());
        }
        if (result4.isPresent()){
            limite = Integer.parseInt(result4.get());
        }
        if (result5.isPresent()){
            multa = Double.parseDouble(result5.get());
        }
        contas.put(numero, new ContaEspecial(limite, multa, nome, numero, saldo));
    }
    
    
    
    //metodo para fechar a aplicacao
    @FXML
    private void closeButtonAction(){
        // get a handle to the stage
        Stage stage = (Stage) sair.getScene().getWindow();
        // do what you have to do
        stage.close();
}
    
    @FXML
    private void saque(){
        TextInputDialog dialog  =  new TextInputDialog(null);
        dialog.setTitle("Saque Bancario");
        dialog.setHeaderText("Numero da conta");
        dialog.setContentText("Insira o numero da sua conta: ");
        
        TextInputDialog dialog2  =  new TextInputDialog(null);
        dialog2.setTitle("Saque Bancario");
        dialog2.setHeaderText("Valor a ser sacado");
        dialog2.setContentText("Insira a quantidade que ira sacar: ");
        
        Optional<String> result = dialog.showAndWait();
        Optional<String> result2 = dialog2.showAndWait();
        
        Contas c = contas.get(Integer.parseInt(result.get()));

        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirme a Operacao");
        alert.setHeaderText("Tem certeza que ira sacar?");
        alert.setContentText(null);

        Optional<ButtonType> result3 = alert.showAndWait();
        if (result3.get() == ButtonType.OK){
            if(c.sacar(Double.parseDouble(result2.get())) == 0){
                Alert alert2 = new Alert(AlertType.INFORMATION);
                alert2.setTitle("Saque Efetuado");
                alert2.setHeaderText(null);
                alert2.setContentText(c.toString());
                alert2.showAndWait(); 
            }else{
                Alert alert3 = new Alert(AlertType.ERROR);
                alert3.setTitle("Operacao Invalida");
                alert3.setHeaderText("Saldo Insuficiente");
                alert3.setContentText("Nao tem saldo e/ou limite ultrapassado");
                alert3.showAndWait();
            }
            
        }else{
            Alert alert2 = new Alert(AlertType.INFORMATION);
            alert2.setTitle("Operacao Cancelada");
            alert2.setHeaderText(null);
            alert2.setContentText("Saque nao efetuado");
            alert2.showAndWait();   
        }
    }
    
    @FXML
    private void deposito(){
        TextInputDialog dialog  =  new TextInputDialog(null);
        dialog.setTitle("Deposito Bancario");
        dialog.setHeaderText("Numero da conta");
        dialog.setContentText("Insira o numero da sua conta: ");
        
        Optional<String> result = dialog.showAndWait();
        
        
        if (result.isPresent()){
            TextInputDialog dialog2  =  new TextInputDialog(null);
            dialog2.setTitle("Deposito Bancario");
            dialog2.setHeaderText("Valor a ser depositado");
            dialog2.setContentText("Valor: ");
        
            Optional<String> result2 = dialog2.showAndWait();

            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confirmation Dialog");
            alert.setHeaderText("Look, a Confirmation Dialog");
            alert.setContentText("Are you ok with this?");

            Optional<ButtonType> res = alert.showAndWait();
            if (res.get() == ButtonType.OK){
                if(contas.get(Integer.parseInt(result.get())) != null){
                    contas.get(Integer.parseInt(result.get())).depositar(Double.parseDouble(result2.get()));
                }else{
                    Alert alert1 = new Alert(AlertType.ERROR);
                    alert1.setTitle("Error");
                    alert1.setHeaderText("Conta nao encontrada");
                    alert1.setContentText("Verifique se vc digitou o numero certo da conta");

                    alert.showAndWait();    
                }
            } else {
                Alert alert2 = new Alert(AlertType.INFORMATION);
                alert2.setTitle("Operacao Cancelada");
                alert2.setHeaderText(null);
                alert2.setContentText("Operacao nao efetuado");
                alert2.showAndWait(); 
            }
        }
     }
    
    @FXML
    private void transferir(){
        TextInputDialog dialog = new TextInputDialog(null);
        dialog.setTitle("Transferencia");
        dialog.setHeaderText("Numero da Conta que ira transferir");
        dialog.setContentText("Numero: ");
        
        
        Optional<String> result = dialog.showAndWait();
        
        if (result.isPresent()){
            TextInputDialog dialog2 = new TextInputDialog(null);
            dialog2.setTitle("Transferencia");
            dialog2.setHeaderText("Numero da Conta que receber a transferencia");
            dialog2.setContentText("Numero: ");

            // Traditional way to get the response value.
            Optional<String> result2 = dialog2.showAndWait();
            
            TextInputDialog dialog3 = new TextInputDialog(null);
            dialog3.setTitle("Transferencia Bancaria");
            dialog3.setHeaderText("Valor a ser transferido");
            dialog3.setContentText("Valor: ");

            // Traditional way to get the response value.
            Optional<String> result3 = dialog3.showAndWait();
            
            Alert alert = new Alert(AlertType.CONFIRMATION);
            alert.setTitle("Confime a operacao");
            alert.setHeaderText("Tem certeza que quer transferir?");
            alert.setContentText(null);

            Optional<ButtonType> result4 = alert.showAndWait();
            if (result4.get() == ButtonType.OK){               
                if (result.isPresent()){
                    contas.get(Integer.parseInt(result.get())).sacar(Double.parseDouble(result3.get()));
                    contas.get(Integer.parseInt(result2.get())).depositar(Double.parseDouble(result3.get()));
                }
            }else{
                Alert alert2 = new Alert(AlertType.INFORMATION);
                alert2.setTitle("Operacao Cancelada");
                alert2.setHeaderText(null);
                alert2.setContentText("Operacao nao efetuado");
                alert2.showAndWait();
            }
        }
    }
    
    @FXML
    private void reajuste(){
        TextInputDialog dialog  =  new TextInputDialog(null);
        dialog.setTitle("Reajuste");
        dialog.setHeaderText("Numero da conta");
        dialog.setContentText("Insira o numero da sua conta: ");
        
        Optional<String> result = dialog.showAndWait();
        
        TextInputDialog dialog2  =  new TextInputDialog(null);
        dialog2.setTitle("Reajuste");
        dialog2.setHeaderText("Taxa que ira ser aplicada");
        dialog2.setContentText("Taxa: ");
        
        Optional<String> result2 = dialog2.showAndWait();        
        
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Confirme o Reajuste");
        alert.setHeaderText("Tem certeza que quer fazer o reajuste?");
        alert.setContentText("Clique em OK, se sim");

        Optional<ButtonType> result3 = alert.showAndWait();
        if (result3.get() == ButtonType.OK){
            ContaPoupanca c = (ContaPoupanca) contas.get(Integer.parseInt(result.get()));
            if(result2.get() != null)
                c.reajustar(Double.parseDouble(result2.get()));
            else
                c.reajustar();
        }else{
            Alert alert2 = new Alert(AlertType.INFORMATION);
            alert2.setTitle("Operacao Cancelada");
            alert2.setHeaderText(null);
            alert2.setContentText("Operacao nao efetuado");
            alert2.showAndWait();
        }  
    }
        
    @FXML
    private void saldos(){
        String stringstream = "";
        
        for(Contas conta : contas.values()){
            stringstream = stringstream + conta.toString();
        }
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Saldos Disponiveis");
        alert.setHeaderText(null);
        alert.setContentText(stringstream);

        alert.showAndWait();  
        
    }
    
    
    //TODO
    //DEPOSITO
    //Termina Saque
    //Transferir 
    //Reajustar
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Boas Vindas Ao Sistema");
        alert.setHeaderText("Clique em cadastro para cadastrar cada Conta");
        alert.setContentText("Boas-Vindas");
        alert.showAndWait();
    }    
    
}
