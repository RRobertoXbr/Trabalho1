/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;
/**
 * @author roberto
 */
public class Contas {
    private String nome;
    private int numero;
    private double saldo;
    
    public void depositar(double valor){
        this.saldo = this.saldo + valor;
    }
    
    public int sacar(double valor){
        if(saldo > valor){
            saldo = saldo - valor;
            return 0;
        }
        else{
            return -1;
        }
    }

    public String tipoConta(){
        return "Conta Normal"; 
    }
    
    public Contas(String nome, int numero, double saldo) {
        this.nome = nome;
        this.numero = numero;
        this.saldo = saldo;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getNumero() {
        return numero;
    }

    public void setNumero(int numero) {
        this.numero = numero;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    @Override
    public String toString() {
        return "[" + numero + "] " + nome + " Saldo:" + saldo + "\n";  //To change body of generated methods, choose Tools | Templates.
    }
}
