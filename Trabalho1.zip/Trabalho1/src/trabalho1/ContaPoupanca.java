/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;
/**
 * @author brenocg
 */
public class ContaPoupanca extends Contas {
    public ContaPoupanca(String nome, int numero, double saldo) {
        super(nome, numero, saldo);
    } 
    public void reajustar(){
        depositar((getSaldo() * 0.1));
    }
    public void reajustar(double valor){
        depositar((getSaldo() * (valor/100)));
    }
    @Override
    public String tipoConta(){
        return "Conta Poupanca"; 
    }    
}
