/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalho1;

/**
 *
 * @author brenocg
 */
public class ContaEspecial extends Contas{
    private int limite; 
    private double multa;
    
    public void descontar(double valor){
    }
    
    public int sacar(double valor) {
        if(super.sacar(valor) == -1){
            if(valor > limite + getSaldo()){
                return -1;
            }else{
                setSaldo((((multa/100) * (getSaldo()- valor))) + (getSaldo() - valor));
                System.out.println(multa);
                return 0;
            }
        }
        return 0;
    }
    
    @Override
    public String tipoConta(){
        return "ContaEspecial";
    }
    
    public ContaEspecial(String nome, int numero, double saldo) {
        super(nome, numero, saldo);
    }

    public ContaEspecial(int limite, double multa, String nome, int numero, double saldo) {
        super(nome, numero, saldo);
        this.limite = limite;
        this.multa = multa;
    }
    
    public int getLimite() {
        return limite;
    }

    public void setLimite(int limite) {
        this.limite = limite;
    }
}
